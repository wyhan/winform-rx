﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeProjectWin
{
    public class Command:ICommand
    {

        #region ICommand Members

        public void Execute()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
