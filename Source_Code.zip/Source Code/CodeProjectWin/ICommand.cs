﻿
namespace CodeProjectWin
{
    public interface ICommand
    {
        void Execute(object sender);        
    }
}
